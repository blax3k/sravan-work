-- 
-- Abstract: ManyCrates sample project
-- Demonstrates simple body construction by generating 100 random physics objects
-- 
-- Version: 1.1 (revised for Alpha 2)
-- 
-- Sample code is MIT licensed, see http://developer.anscamobile.com/code/license
-- Copyright (C) 2010 ANSCA Inc. All Rights Reserved.

local physics = require("physics")
physics.setDrawMode("hybrid")
physics.start(true)
physics.setGravity(0,9.8)

display.setStatusBar( display.HiddenStatusBar )

local bkg = display.newImageRect( "bkg_cor.png",960,640 )
bkg.x = display.contentWidth*.5
bkg.y = display.contentHeight*.5
local basketimg

for i=1,10 do
local rect = display.newRect((i-1)*96,400-i,96,20)
rect:setFillColor(0,200,120)
physics.addBody( rect, "static", { friction=0.5, bounce=0.2 } )
end

local direction = 1

function Mover()
    print("mover")
    local vx, vy = basketimg:getLinearVelocity()

    if basketimg.x > 700 then
        print("changing direction")
        direction = -1
    elseif basketimg.x < 200 then
        direction = 1
    end
    basketimg:setLinearVelocity(105*direction, vy)
end

function setground()


   basketimg = display.newImageRect("Cart_01.png",150,105)
   basketimg.x = 100
   basketimg.y = 330
   local data =(require "cartstrace1").physicsData(.5)
   physics.addBody(basketimg,"dynamic",data:get("Cart_01"))

   local gemdata =(require "gems").physicsData(.3)

    for s=1,5 do
        local gem = display.newImageRect("Nugget_ruby1.png", 52, 52)
        gem.x = basketimg.x
        if s%3 == 1 then
            gem.x = gem.x - 25
        elseif s%3 == 2 then
            gem.x = gem.x
        else
            gem.x = gem.x + 20
        end

        gem.y = basketimg.y-s*30
        physics.addBody(gem, "dynamic", gemdata:get("Nugget_ruby1"))


    end

   timer.performWithDelay(1500, Mover,0)
end

setground()

